function [BestSol] = aco_TSP_45913106(model,nants,niter)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% GENERATION OF EMPTY INPUT VARIABLES %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if nargin<1,model=generamodelo_45913106(20,10,0); end %generate a random model
    if nargin<3,niter=50; end
    if nargin<2,nants=10; end      
nest=1;
save('modelo','model');
    
    

%%%%%%%%%%%%%%%%%
% ACO PARAMETERS %
%%%%%%%%%%%%%%%%%
MaxIt=niter;      % Maximum Number of Iterations
nAnt=nants;        % Number of Ants (Population Size)
alpha=1;        % Phromone Exponential Weight
beta=1;         % Heuristic Exponential Weight
rho=0.05;       % Evaporation Rate
Q=1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INITIALIZE eta (visibility) and tau (PHEROMONE) %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eta=1./model.D; %Matriz de visibilidad
nVar=length(model.x); %N�mero de nodos
tau0=10*Q/(nVar*mean(model.D(:))); %Feromona inicial
tau=tau0*ones(nVar,nVar); %Matriz de todas las feromonas


%%%%%%%%%%%%%%%%%
% ACO Main Loop %
%%%%%%%%%%%%%%%%%
for k=1:MaxIt
% Dentro del este bucle principal probablemente necesitar�s las siguientes secciones:
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Initialize each Ants at nest %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for n=1:nants
   ant(n).Tabu=nest;
   ant(n).Cost=[];
end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Construct a solution for each ANT
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    exitosas=0;
    exito = false;
while(~exito)
for n=1:nants %Recorre todas las hormigas    
    antPath=ant(n).Tabu;
    pos=antPath(length(antPath)); %Posici�n actual obtenida del vector del camino   
    
    %%Comprueba si la posicion actual es en la comida y salta a la
    %%siguiente hormiga
    if length(antPath)==length(model.x)+1 && antPath(length(antPath))==nest %if es el ultimo y esta en el objetivo salta a la siguiente hormiga
        continue     
    
    %%No ha llegado a la comida y sigue buscando
    else
        auxNei=model.nei{pos};%Los vecinos en la posicion de la hormiga
        checkNei=auxNei;%Almacena los vecinos en una variable variante
        allP=[];%Inicializa el vector de todas las prob entre la hormiga y los vecinos
        
        %%calcula tau y eta de la posicion con los posibles vecinos que no se hayan visitado ya. 
        %%Obtenemos el vector con las probabilidades de saltar a cada
        %%posible vecino
        
        for p=1:length(auxNei) %Indices de la matrix auxiliar de vecinos        
            posiblesalto=auxNei(p); %Obtiene un posible salto de model.nei{p}=auxNei(p)
            comprobar=find(antPath==posiblesalto); %Comprobar si posiblesalto ya se encuentra en el camino de la ant
            if isempty(comprobar) %Comprueba si se ha devuelto alg�n indice indicando que por ese nodo ya ha pasado la hormiga
                %Si no hay indice indica que la hormiga no ha pasado por
                %ese nodo
                %Calculamos probabilidad hacia el posiblesalto
                TauVecino=tau(pos,posiblesalto);%Obtenemos la feromona del camino hacia el nodo vecino
                EtaVecino=eta(pos,posiblesalto);%Obtenemos la visibilidad del nodo vecino         
                allP=[allP (TauVecino^alpha)*(EtaVecino^beta)]; %Vecotr que almacena los valores del sumatorio del denominador de la formula de pij       
        
            else %Si la hormiga ha pasado ya por el posible salto entonces:
                if posiblesalto==nest && length(antPath)==length(model.x) %comprueba que el posible salto es el objetivo y que es el penultimo nodo posible
                    TauVecino=tau(pos,posiblesalto);%Obtenemos la feromona del camino hacia el nodo vecino
                    EtaVecino=eta(pos,posiblesalto);%Obtenemos la visibilidad del nodo vecino         
                    allP=[allP (TauVecino^alpha)*(EtaVecino^beta)];%Vecotr que almacena los valores del sumatorio del denominador de la formula de pij 
                else
                elimNei=find(checkNei==posiblesalto); %Obtiene el indice donde se encuentra el nodo que se desea eliminar de posibles saltos
                checkNei(elimNei,:)=[]; %Elimina el nodo del vecto. Se utiliza una variable extra para no interferir en el for que utiliza auxNei.  
                end
            end 
        
        end
    
        sumaP = sum(allP); %Sumatorio del denominador de la formula pij
        P=[]; %Inicializa el vector P donde se almacenar�n las probabilidades del cumsum
    
    
        %%Calculamos la probabilidad para cada caso y creamos el vector P
        for p=1:length(allP) %Recorre todo el vector sumaP que indica cuantas probabilidades se han calculado y por tanto cuantos posibles vecinos hay
        P=[P allP(p)/sumaP]; %Almacena las probabilidades pij
        end
    
    
        %%Elegimos de forma heuristica el nodo al que iremos
        r=rand;
        C=cumsum(P);
        j=find(r<=C,1,'first'); %selecciona el primero mayor que r y devuelve el indice
        %%Elige un posible salto entre todos y se a�ade al vector de nodos
        %%recorridos por la hormiga
        ant(n).Tabu=[antPath checkNei(j)];%introduce en el path el nodo seleccionado
    
        %%Comprueba si no hay vecinos a los que ir y reinicia el path
        %%Exactamente comprueba si se han eliminado todos los posibles
        %%saltos en el proceso anterior, esto indicar� que el nodo no ha
        %%encontrado un camino por donde avanzar.
        if isempty(checkNei)
            antPath=[nest]; %Devuelve a la hormiga al nest
            ant(n).Tabu=antPath; %Reinicia la variable 
            continue %Salta a la siguiente hormiga
        end
        
        %%Comprueba si ha llegado la hormiga a la comida
        antPath=ant(n).Tabu; %Actualiza la varible con el avance de la hormiga incluido
        pos=antPath(length(antPath));%Actualiza la variable con el nodo actual de la hormiga
        if length(antPath)==length(model.x)+1 && antPath(length(antPath))==nest %Compara la el nodo de la hormiga con el de la comida
            exitosas=exitosas+1; %Si encuentra la comida suma +1 a las hormiga que han logrado llegar a la comida
            if exitosas==nants %Comprueba si todas las hormigas han llegado
                exito=true; %En de llegar todas se cambia el valor de la booleana exito
                
            end
        end 

    end    
end
end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % UPDATE PHEROMONES
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        sumCoste=[];%Inicializamos el sumatorio de los costes
        for p=1:nants %Recorre todas las hormigas
            antPath=ant(p).Tabu;%Obtenemos el camino que ha llevado la hormiga
            coste=[ant(p).Cost];%Inicializamos el coste con el valor almacenado. Aqu� se almacenar�n los costes de cada salto para una �nica hormiga(inicializado en vacio)
            
            %For para almacenar la distancia entre todos los saltos
            for l=2:length(antPath)
                nodoi=antPath(l-1);%Obtenemos el nodo i
                nodoj=antPath(l);%Obtenemos el nodo j
                coste=[coste model.D(nodoi,nodoj)]; %A�adimos la distancia entre cada salto del camino seguido por la hormiga
                
            end 
            
            coste=sum(coste); %Sumamos las distancias del vector de una hormiga y obtenemos la distancia total recorrida
            ant(p).Cost=coste; %Almacenamos la distancia de una hormiga
            sumCoste=[sumCoste coste ];%Almacenamos en un vector aux el coste de todas las hormigas. Lo utilizaremos para encontrar el minimo valor entre todas las hormigas

        end
        
        betterant = find(sumCoste==min(sumCoste)); %Apunta a la hormiga con el camino mas corto
        betterpath = ant(betterant).Tabu; %Obtiene el camino de la hormiga con menor coste
        varFijatau=mrdivide(Q,ant(betterant(1)).Cost);%Calculo la variable que es constante. Apunta al �ndice 1 ya que puede ser que varias hormigas tengan el mismo coste, por ranto se elige la primera hormiga
        %x = mrdivide(B,A) forma alternativa de hacer div (utilizada porque
        %pensaba que la habitual fallaba :=) )
        for l=2:length(betterpath)%Recorre los indices del mejor camino
                nodoi=betterpath(l-1); %Nodosi
                nodoj=betterpath(l); %Nodosj
                tau(nodoi,nodoj)=tau(nodoi,nodoj)+varFijatau; %Actualizamos las distancias en la matriz de feromonas
                
        end 
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%
        tau=(1-rho)*tau; %Evaporamos una parte de todos los caminos
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%
        %GENERATE OUTPUT VARIABLE%
        %%%%%%%%%%%%%%%%%%%%%%%%%%
        BestSol.Tabu=betterpath;
        BestSol.Cost=min(sumCoste);
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Show IterationInformation
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        disp(['Iteration' num2str(k) ': Best Cost = ' num2str(BestSol.Cost)]);
        %figure 
        plotdistribution2(model,tau) %plot map and distribution of pheromone
        title(['Generated model. Iteration: ' num2str(k)],'FontWeight','bold')
        pause(0.2) %stop during0.1 seconds to allow the user to see the progression

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Show/Plot pheromone update
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%
end

